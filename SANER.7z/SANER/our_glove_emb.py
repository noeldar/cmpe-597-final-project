from gensim.models import KeyedVectors
from gensim.scripts.glove2word2vec import glove2word2vec
import os

glove_file = 'D:\\cmpe597\\glove\\vectors\\vectors.txt'
word2vec_file = "D:\\cmpe597\\glove\\vectors\\word2Vec.txt"

#glove2word2vec(glove_file, word2vec_file)

#word2vec_file = "D:\\cmpe597\\glove\\vectors\\vectors.txt"
model = KeyedVectors.load_word2vec_format(word2vec_file)

# Synonyms & Antonyms
w1 = "fakir"
w2 = "yoksul"
w3 = "zengin"
w1_w2_dist = model.distance(w1, w2)
w1_w3_dist = model.distance(w1, w3)

print(f"Synonyms {w1}, {w2} have cosine distance: {w1_w2_dist}")
print(f"Antonyms {w1}, {w3} have cosine distance: {w1_w3_dist}")
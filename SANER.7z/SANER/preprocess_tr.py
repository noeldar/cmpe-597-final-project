

for filename in ["data/dataset/gungor.ner.dev.14.only_consistent", "data/dataset/gungor.ner.test.14.only_consistent", "data/dataset/gungor.ner.train.14.only_consistent"]:
    with open(filename) as file:
        lines = [line.rstrip() for line in file]

    new_lines = []
    cnt = 0

    for line in lines:
        if cnt > 2000:
            break
        if line.strip() != "":
            tokens = line.split()
            new_lines.append(tokens[0]+" "+tokens[-1])
        else:
            cnt = cnt + 1
            new_lines.append(line)

    if "dev" in filename:
        ff = "dev.txt"
    elif "train" in filename:
        ff = "train.txt"
    else:
        ff = "test.txt"

    with open(f"data/tr_SampleSet_long/{ff}", 'w') as f:
        for item in new_lines:
            f.write("%s\n" % item)
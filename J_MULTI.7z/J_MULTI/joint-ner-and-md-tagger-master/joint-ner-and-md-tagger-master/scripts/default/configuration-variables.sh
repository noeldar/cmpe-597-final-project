#!/usr/bin/env bash
export ner_tagger_root=/media/isik/yedek/cmpe597/joint-ner-and-md-tagger-master/joint-ner-and-md-tagger-master
export virtualenv_name=python3
export datasets_root=/media/isik/yedek/cmpe597/joint-ner-and-md-tagger-master/joint-ner-and-md-tagger-master/datasets/
export experiment_logs_path=/media/isik/yedek/cmpe597/joint-ner-and-md-tagger-master/joint-ner-and-md-tagger-master/experiment-logs/

export virtualenvwrapper_path=/home/isik/.local/bin/virtualenvwrapper.sh
export sacred_args='-F '${experiment_logs_path}